

# Actividad 1. Convenciones y código limpio (clean code)

Programa en Java que lleva el control de la selección Mexicana implementando herencia y aplicando las siguientes
convenciones de código de Google Style Guide:

- Nombramiento de clases (Primera mayúscula)
- camelCase
- Especificar constructores
- Uso de anotaciones como @Override
- Una sentencia por linea.

