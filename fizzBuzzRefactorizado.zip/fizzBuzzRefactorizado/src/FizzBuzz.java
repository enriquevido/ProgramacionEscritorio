public interface FizzBuzz {
    void printNumbers(int from, int to);
}
