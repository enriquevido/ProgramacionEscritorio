public interface CalculatorMethods {
    public void DetermineOperation(String operand1, String operator, String operand2);
}
