public class Main {
    public static void main(String[] args) {
        ConsoleBasedFizzBuzz prueba = new ConsoleBasedFizzBuzz();
        prueba.printFizzBuzz(1, 100);
    }
}
