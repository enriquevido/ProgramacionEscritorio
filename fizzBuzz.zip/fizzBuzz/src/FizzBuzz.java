public interface FizzBuzz {
    void printFizzBuzz(int from, int to);
}
